//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GAME1007_SDLTemplate.rc
//
#define IDB_PNG1                        101
#define IDB_PNG2                        102
#define IDB_PNG3                        105
#define IDB_PNG4                        106
#define IDB_PNG5                        107
#define IDB_PNG6                        108

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
