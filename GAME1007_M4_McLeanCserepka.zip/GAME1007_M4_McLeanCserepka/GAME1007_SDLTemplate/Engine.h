#pragma once
#ifndef _ENGINE_H_
#define _ENGINE_H_

#include <iostream>
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_mixer.h"
#include <vector>
#include <stdlib.h>
#include <time.h>
#define FPS 60
#define WIDTH 1024
#define HEIGHT 768
using namespace std;

class Sprite
{
public: // Keeping like this in the interest of time.
	SDL_Rect m_src; // Source rectangle.
	SDL_Rect m_dst; // Destination rectangle.

	void setRects(SDL_Rect s, SDL_Rect d)
	{
		m_src = s;
		m_dst = d;
	}
	SDL_Rect* Getsrc()
	{
		return &m_src;
	}
	SDL_Rect* GetDst()
	{
		return &m_dst;
	}
};

class AnimatedSprite : public Sprite
{
private:
	int m_frame = 0, // "currentFrame" property.
		m_frameMax = 10, // Number of frames to dislpay each sprite.
		m_sprite = 0, // Which sprite of the animation to display.
		m_spriteMax = 5, // Number of sprites in the animation.

		m_frameIdle = 0,
		m_frameMaxIdle = 8,
		m_spriteIdle = 0,
		m_spriteMaxIdle = 4;
public:
	bool m_faceLeft = 0; // 0 = To facing right.
	void SetRects(SDL_Rect s, SDL_Rect d)
	{
		m_src = s;
		m_dst = d;
	}

	void Animate()
	{
		 //Long way:
		if (m_frame == m_frameMax) // Or m_frame++ and eliminate the m_frame++; line.
		{
			m_src.y = 0;
			m_frame = 0;
			m_sprite++;
			if (m_sprite == m_spriteMax) // Or ++m_sprite == m_spriteMax
				m_sprite = 0; // Or set to m_spriteMin if row has multiple animations.
			m_src.x = m_src.w * m_sprite;
		}
		m_frame++;
		// Shorter way:
		/*if (m_frame++ % m_frameMax == 0)
			m_src.x = m_src.w * (m_sprite++ % (m_spriteMax));*/ // 128 * <our sprite ctr>
	}

	void Idle()
	{
		m_src.x = 0;
		if (m_frameIdle++ % m_frameMaxIdle == 0)
			m_src.y = m_src.h * (m_spriteIdle++ % (m_spriteMaxIdle));
	}
};

class Bullet : public Sprite
{
public:
	Bullet(SDL_Rect spawnLoc = { 512, 384 })
	{
		cout << "Pew." << endl;
		this->m_dst.x = spawnLoc.x;
		this->m_dst.y = spawnLoc.y;
		this->m_dst.w = 50;
		this->m_dst.h = 50;
		m_src = { 0,0,280,200 };
	}
	~Bullet()
	{
		cout << "De-allocating Bullet at" << &(*this) << endl;
	}
	void setLoc(SDL_Point loc)
	{
		m_dst.x = loc.x;
		m_dst.y = loc.y;
	}
	void Update()
	{
		this->m_dst.x += 15;
	}
	void Render(SDL_Renderer* rend, SDL_Texture* tex)
	{
		SDL_RenderCopy(rend, tex, &m_src, &m_dst);
	}
};

class LaserBeam : public Sprite
{
public:
	LaserBeam(SDL_Rect spawnLoc)
	{
		this->m_dst.x = spawnLoc.x;
		this->m_dst.y = spawnLoc.y;
		this->m_dst.w = 25;
		this->m_dst.h = 25;
		m_src = { 0,0,1120,800 };
	}

	~LaserBeam()
	{

	}
	void SetLoc(SDL_Point loc)
	{
		m_dst.x = loc.x;
		m_dst.y = loc.y;
	}
	void Update()
	{
		this->m_dst.x -= 10;
	}
	void Render(SDL_Renderer* rend, SDL_Texture* tex)
	{

		SDL_RenderCopy(rend, tex, &m_src, &m_dst);

	}
};

class Enemy : public Sprite
{
public:
	int m_shootTimer = 85;
	Enemy(SDL_Rect spawnLoc)
	{
		this->m_dst.x = spawnLoc.x;
		this->m_dst.y = spawnLoc.y;
		this->m_dst.w = 100;
		this->m_dst.h = 100;
		this->m_src = { 0, 0, 128, 128 };
	}

	~Enemy()
	{

	}

	int getTimer()
	{
		return m_shootTimer;
	}

	void setLoc(SDL_Point loc)
	{
		m_dst.x = loc.x;
		m_dst.y = loc.y;
	}

	void Update()
	{
		this->m_dst.x -= 4;
	}
	void Render(SDL_Renderer* rend, SDL_Texture* tex)
	{
		SDL_RenderCopy(rend, tex, &m_src, &m_dst);
	}
};

class Asteroid : public Sprite
{
public:
	Asteroid(SDL_Rect spawnLoc)
	{
		this->m_dst.x = spawnLoc.x;
		this->m_dst.y = spawnLoc.y;
		this->m_dst.w = 100;
		this->m_dst.h = 100;
		this->m_src = { 0, 0, 128, 128 };
	}

	~Asteroid()
	{

	}

	void setLoc(SDL_Point loc)
	{
		m_dst.x = loc.x;
		m_dst.y = loc.y;
	}

	void Update()
	{
		this->m_dst.x -= 3;
	}
	void Render(SDL_Renderer* rend, SDL_Texture* tex)
	{
		SDL_RenderCopy(rend, tex, &m_src, &m_dst);
	}
};

class Bomb : public AnimatedSprite
{
public:
	bool explode = false;
	int expLength = 0;
	Bomb(SDL_Rect spawnLoc)
	{
		this->m_dst.x = spawnLoc.x;
		this->m_dst.y = spawnLoc.y;
		this->m_dst.w = 120;
		this->m_dst.h = 60;
		this->m_src = { 0, 0, 120, 60 };
	}

	~Bomb()
	{

	}

	bool BoomBoom()
	{
		return explode;
	}

	int BoomLength()
	{
		return expLength;
	}

	void setLoc(SDL_Point loc)
	{
		m_dst.x = loc.x;
		m_dst.y = loc.y;
	}

	void Update()
	{
		this->m_dst.x -= 5;
	}
	void Render(SDL_Renderer* rend, SDL_Texture* tex)
	{
		SDL_RenderCopy(rend, tex, &m_src, &m_dst);
	}
};

class Engine
{
private: // private properties.
	bool m_running = false;
	Uint32 m_start, m_end, m_delta, m_fps;
	const Uint8* m_keystates;
	SDL_Window* m_pWindow;
	SDL_Renderer* m_pRenderer;

	SDL_Texture* m_aTexture;
	SDL_Texture* m_aLTexture;
	SDL_Texture* m_lTexture;
	SDL_Texture* m_pTexture;
	SDL_Texture* m_pBGTexture;
	SDL_Texture* m_aSTexture;
	SDL_Texture* m_bTexture;
	Sprite m_bg1, m_bg2;

	Sprite* m_player;
	vector<Bullet*> m_laser;
	vector<Enemy*> m_aliens; // Making a list of the enemies
	vector<LaserBeam*> m_shoot;
	vector<Asteroid*> m_asteroid;
	vector<Bomb*> m_bomb;

	int m_speed = 10; // In-class initialization. Not normal.
	int m_spawn = 150;
	int m_aSpawn = 200;
	int m_bSpawn = 100;
	int numAsteroid = 0;
	bool m_switch = true;

	// Sound effect objects.
	Mix_Chunk* m_boom;
	Mix_Chunk* m_death;
	Mix_Chunk* m_plaser;
	Mix_Chunk* m_alaser;
	Mix_Chunk* m_kaboom;
	// Music track objects;
	Mix_Music* m_odd;


private: // private method prototypes.
	int Init(const char* title, int xPos, int yPos, int width, int height, int flags);
	void Clean();
	void Wake();
	void HandleEvents();
	bool KeyDown(SDL_Scancode c);
	void Update();
	void Render();
	void Sleep();

public: // public method prototypes.
	int Run();
};

#endif
