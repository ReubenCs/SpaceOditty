#include "Engine.h"
#include "SDL_image.h"
#include "SDL.h"
#include "SDL_mixer.h"

int Engine::Init(const char* title, int xPos, int yPos, int width, int height, int flags)
{
	cout << "Initializing engine..." << endl;
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0) // If initialization is okay...
	{
		// Create the SDL window...
		m_pWindow = SDL_CreateWindow(title, xPos, yPos, width, height, flags);
		if (m_pWindow != nullptr)
		{
			// Create the SDL renderer...(back buffer)
			m_pRenderer = SDL_CreateRenderer(m_pWindow, -1, NULL);
			if (m_pRenderer != nullptr)
			{
				// Initialize subsystems...
				if (IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG) != 0)
				{
					m_pTexture = IMG_LoadTexture(m_pRenderer, "ship.png.png");
					m_pBGTexture = IMG_LoadTexture(m_pRenderer, "Background.png.png");
					m_lTexture = IMG_LoadTexture(m_pRenderer, "laser.png");
					m_aTexture = IMG_LoadTexture(m_pRenderer, "alien.png");
					m_aLTexture = IMG_LoadTexture(m_pRenderer, "alienLaser.png");
					m_aSTexture = IMG_LoadTexture(m_pRenderer, "asteroid.png");
					m_aSTexture = IMG_LoadTexture(m_pRenderer, "asteroid.png");
					m_bTexture = IMG_LoadTexture(m_pRenderer, "LaBamba.png");
				}
				else return false; // Image init failed.
				if (Mix_Init(MIX_INIT_MP3) != 0)
				{
					Mix_OpenAudio(22050, AUDIO_S16SYS, 2, 2048);
					Mix_AllocateChannels(16);
					// Load sounds.
					m_boom = Mix_LoadWAV("Aud/boom.wav");
					m_death = Mix_LoadWAV("Aud/death.wav");
					m_plaser = Mix_LoadWAV("Aud/laser.wav");
					m_alaser = Mix_LoadWAV("Aud/aLaser.wav");
					m_odd = Mix_LoadMUS("Aud/SpaceOddity.mp3");
				}
				else return false; // Mixer init failed
			}
			else return false; // Renderer creation failed.
		}
		else return false; // Window creation failed.
	}
	else return false; // initalization failed.
	m_fps = (Uint32)round(1.0 / (double)FPS * 1000); // Converts FPS into milliseconds, e.g. 16.67
	m_keystates = SDL_GetKeyboardState(nullptr);
	m_player = new Sprite;
	m_player->setRects({ 0,0,100,100 }, { 0,334,100,100 }); // First {} is src rectangle, and second {} destination rect
	m_bg1 = { {0, 0, 1024, 768}, {0, 0, 1024,768} };
	m_bg2 = { {0, 0, 1024, 768}, {1024, 0, 1024,768} };

	for (int i = 0; i < m_laser.size(); i++)
	{
		m_laser[i]->setRects({ 0,0,280,200 }, { m_player->GetDst()->x, m_player->GetDst()->y, 16, 16 });
	}
	for (int i = 0; i < m_aliens.size(); i++)
	{
		m_aliens[i]->setRects({ 0,0, 128, 128 }, { 500, rand() % HEIGHT, 100, 100 });
	}
	for (int i = 0; i < m_asteroid.size(); i++)
	{
		m_asteroid[i]->setRects({ 0,0, 128, 128 }, { 500, rand() % HEIGHT, 100, 100 });
	}
	for (int i = 0; i < m_bomb.size(); i++)
	{
		m_bomb[i]->setRects({ 0,0, 120, 60 }, { 500, rand() % HEIGHT, 120, 60 });
	}
	for (int i = 0; i < m_shoot.size(); i++)
	{
		for (int n = 0; n < m_aliens.size(); n++)
		{
			m_shoot[i]->setRects({ 0,0,280, 200 }, { m_aliens[n]->GetDst()->x, m_aliens[n]->GetDst()->y, 15, 15 });
		}
	}
	cout << "Initialization successful!" << endl;
	Mix_PlayMusic(m_odd, -1); // o-n for # of loops, or -1 for infinite looping.
	Mix_VolumeMusic(32); // 0-128.
	m_running = true;
	return true;
}

void Engine::Wake()
{
	m_start = SDL_GetTicks();
}

void Engine::HandleEvents()
{
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT:
			m_running = false;
			break;
		case SDL_KEYUP:
			switch (event.key.keysym.sym)
			{
			case ' ':
				switch (m_switch)
				{
				case true:

					if (m_player != nullptr)
					{
						m_laser.push_back(new Bullet({ m_player->GetDst()->x + 15, m_player->GetDst()->y + 1 }));
						Mix_PlayChannel(-1, m_plaser, 0); // -1 channel is first avilable.
						m_switch = false;
					}
					break;
				case false:

					if (m_player != nullptr)
					{
						m_laser.push_back(new Bullet({ m_player->GetDst()->x + 15, m_player->GetDst()->y + 46 }));
						Mix_PlayChannel(-1, m_plaser, 0);
						m_switch = true;
					}
					break;
				}

				cout << "space bar." << endl;
				break;
			}

			if (event.type == SDL_KEYUP)
			{
				switch (event.key.keysym.sym)
				{
				case '1':
					Mix_PlayMusic(m_odd, -1);
					break;
				case 'p':
					if (Mix_PausedMusic() == true)
					{
						cout << "Music is playing." << endl;
						Mix_ResumeMusic();
					}
					else
					{
						cout << "Music is paused." << endl;
						Mix_PauseMusic();
					}
					break;
				}
			}
			break;
		}
	}
}

bool Engine::KeyDown(SDL_Scancode c)
{
	if (m_keystates != nullptr)
	{
		if (m_keystates[c] == 1)
			return true;
	}
	return false;
}

void Engine::Update()
{
	m_bg1.m_dst.x -= m_speed / 3;
	m_bg2.m_dst.x -= m_speed / 3;

	if (m_bg1.m_dst.x <= -m_bg1.m_dst.w)
	{
		m_bg1.m_dst.x = 0;
		m_bg2.m_dst.x = 1024;
	}
	if (m_player != nullptr)
	{
		if (KeyDown(SDL_SCANCODE_W) && m_player->m_dst.y > 0)
			m_player->m_dst.y -= m_speed;
		else if (KeyDown(SDL_SCANCODE_S) && m_player->m_dst.y < HEIGHT - m_player->m_dst.h)
			m_player->m_dst.y += m_speed;
		if (KeyDown(SDL_SCANCODE_A) && m_player->m_dst.x > 0)
			m_player->m_dst.x -= m_speed;
		else if (KeyDown(SDL_SCANCODE_D) && m_player->m_dst.x < (WIDTH / 2) - m_player->m_dst.w)
			m_player->m_dst.x += m_speed;
	}

	for (int i = 0; i < m_laser.size(); i++)
	{
		m_laser[i]->Update();
	}

	m_spawn--;
	if (m_spawn <= 0)
	{
		m_aliens.push_back(new Enemy({ 1024, rand() % 668 }));
		cout << "Aliens!" << endl;
		m_spawn = 80;
	}
	m_aSpawn--;
	if (m_aSpawn <= 0)
	{
		numAsteroid = 1 + (rand() % 4);
		cout << "Asteroids: " << numAsteroid + 1 << endl;
		if (numAsteroid == 1)
		{
			m_asteroid.push_back(new Asteroid({ 1024, rand() % 284 }));
			m_asteroid.push_back(new Asteroid({ 1024, 384 + (rand() % 284) }));
		}
		else if(numAsteroid == 2)
		{
			m_asteroid.push_back(new Asteroid({ 1024, rand() % 156 }));
			m_asteroid.push_back(new Asteroid({ 1024, 256 + (rand() % 156) }));
			m_asteroid.push_back(new Asteroid({ 1024, 512 + (rand() % 156) }));
			
		}
		else if (numAsteroid == 3)
		{
			m_asteroid.push_back(new Asteroid({ 1024, rand() % 92 }));
			m_asteroid.push_back(new Asteroid({ 1024, 192 + (rand() % 92) }));
			m_asteroid.push_back(new Asteroid({ 1024, 384 + (rand() % 92) }));
			m_asteroid.push_back(new Asteroid({ 1024, 576 + (rand() % 92) }));
		}
		else if (numAsteroid == 4)
		{
			m_aliens.push_back(new Enemy({ 1024, rand() % 156 }));
			m_aliens.push_back(new Enemy({ 1024, 256 + (rand() % 156) }));
			m_aliens.push_back(new Enemy({ 1024, 512 + (rand() % 156) }));
		}
		cout << "INCOMING!!!" << endl;
		m_aSpawn = 256;
	}

	m_bSpawn--;
	if (m_bSpawn <= 0)
	{
		m_bomb.push_back(new Bomb({ 1024, rand() % 708 }));
		cout << "Get Nuked!!" << endl;
		m_bSpawn = 100;
	}

	for (int i = 0; i < m_aliens.size(); i++)
	{
		m_aliens[i]->Update();
	}
	for (int i = 0; i < m_asteroid.size(); i++)
	{
		m_asteroid[i]->Update();
	}
	for (int i = 0; i < m_bomb.size(); i++)
	{
		m_bomb[i]->Update();
	}

	for (int i = 0; i < m_aliens.size(); i++)
	{
		if (m_aliens[i]->GetDst()->x <= -100)
		{
			delete m_aliens[i];
			m_aliens[i] = nullptr;
			m_aliens.erase(m_aliens.begin() + i);
			m_aliens.shrink_to_fit();
			break;
		}
	}
	for (int i = 0; i < m_bomb.size(); i++)
	{
		if (m_bomb[i]->GetDst()->x <= -120)
		{
			delete m_bomb[i];
			m_bomb[i] = nullptr;
			m_bomb.erase(m_bomb.begin() + i);
			m_bomb.shrink_to_fit();
			break;
		}
	}
	for (int i = 0; i < m_asteroid.size(); i++)
	{
		if (m_asteroid[i]->GetDst()->x <= -100)
		{
			delete m_asteroid[i];
			m_asteroid[i] = nullptr;
			m_asteroid.erase(m_asteroid.begin() + i);
			m_asteroid.shrink_to_fit();
			cout << "Left the screen." << endl;
			break;
		}
	}

	for (int i = 0; i < m_aliens.size(); i++)
	{
		m_aliens[i]->m_shootTimer--;
		if (m_aliens[i]->m_shootTimer <= 0)
		{
			m_shoot.push_back(new LaserBeam({ m_aliens[i]->GetDst()->x + 15, m_aliens[i]->GetDst()->y + 37 }));
			cout << "Laser Beam!" << endl;
			Mix_PlayChannel(-1, m_alaser, 0);
			m_aliens[i]->m_shootTimer = rand() % 80 + 30;
		}
	}

	for (int i = 0; i < m_shoot.size(); i++)
	{
		m_shoot[i]->Update();
	}


	for (int i = 0; i < m_laser.size(); i++)
	{
		for (int j = 0; j < m_aliens.size(); j++)
		{
			if (SDL_HasIntersection(m_laser[i]->GetDst(), m_aliens[j]->GetDst()))
			{
				
				delete m_laser[i];
				m_laser[i] = nullptr;
				m_laser.erase(m_laser.begin() + i);
				m_laser.shrink_to_fit();
				Mix_PlayChannel(-1, m_boom, 0);
				delete m_aliens[j];
				m_aliens[j] = nullptr;
				m_aliens.erase(m_aliens.begin() + j);
				m_aliens.shrink_to_fit();
				break;
			}
		}
	}

	for (int i = 0; i < m_laser.size(); i++)
	{
		for (int j = 0; j < m_asteroid.size(); j++)
		{
			if (SDL_HasIntersection(m_laser[i]->GetDst(), m_asteroid[j]->GetDst()))
			{

				delete m_laser[i];
				m_laser[i] = nullptr;
				m_laser.erase(m_laser.begin() + i);
				m_laser.shrink_to_fit();
				break;
			}
		}
	}

	for (int i = 0; i < m_shoot.size(); i++)
	{
		for (int j = 0; j < m_asteroid.size(); j++)
		{
			if (SDL_HasIntersection(m_shoot[i]->GetDst(), m_asteroid[j]->GetDst()))
			{

				delete m_shoot[i];
				m_shoot[i] = nullptr;
				m_shoot.erase(m_shoot.begin() + i);
				m_shoot.shrink_to_fit();
				break;
			}
		}
	}

	if (m_player != nullptr)
	{
		for (int i = 0; i < m_shoot.size(); i++)
		{
			if (SDL_HasIntersection(m_player->GetDst(), m_shoot[i]->GetDst()))
			{
				delete m_shoot[i];
				m_shoot[i] = nullptr;
				m_shoot.erase(m_shoot.begin() + i);
				m_shoot.shrink_to_fit();
				Mix_PlayChannel(-1, m_death, 0);
				delete m_player;
				m_player = nullptr;
				cout << "Player is dead!" << endl;
				break;
			}
		}
	}

	if (m_player != nullptr)
	{
		for (int i = 0; i < m_asteroid.size(); i++)
		{
			if (SDL_HasIntersection(m_player->GetDst(), m_asteroid[i]->GetDst()))
			{
				Mix_PlayChannel(-1, m_death, 0);
				delete m_player;
				m_player = nullptr;
				cout << "Asteroid Collision!" << endl;
				break;
			}
		}
	}

	if (m_player != nullptr)
	{
		for (int i = 0; i < m_bomb.size(); i++)
		{
			if (m_bomb[i]->explode == false)
			{
				if (SDL_HasIntersection(m_player->GetDst(), m_bomb[i]->GetDst()))
				{
					m_bomb[i]->explode = true;
					cout << "KAAAAA-BOOOOOOOM!!!!!" << endl;
				}
			}

			if (m_bomb[i]->explode == true)
			{
				m_bomb[i]->Animate();
				m_bomb[i]->expLength++;

				if (m_bomb[i]->expLength == 50)
				{
					delete m_bomb[i];
					m_bomb[i] = nullptr;
					m_bomb.erase(m_bomb.begin() + i);
					m_bomb.shrink_to_fit();
					m_bomb[i]->explode = false;
				}

				for (int i = 0; i < m_aliens.size(); i++)
				{
					delete m_aliens[i];
					m_aliens[i] = nullptr;
				}
				m_aliens.clear();
				m_aliens.shrink_to_fit();

				for (int i = 0; i < m_shoot.size(); i++)
				{
					delete m_shoot[i];
					m_shoot[i] = nullptr;

				}
				m_shoot.clear();
				m_shoot.shrink_to_fit();

				for (int i = 0; i < m_asteroid.size(); i++)
				{
					delete m_asteroid[i];
					m_asteroid[i] = nullptr;
				}
				m_asteroid.clear();
				m_asteroid.shrink_to_fit();
				
				break;
			}
			else if (m_bomb[i]->explode == false)
			{
				m_bomb[i]->Idle();
			}
		}
	}
}

void Engine::Render()
{
	SDL_SetRenderDrawColor(m_pRenderer, 0, 128, 255, 255);
	SDL_RenderClear(m_pRenderer);
	// Any drawing here...
	SDL_RenderCopy(m_pRenderer, m_pBGTexture, &m_bg1.m_src, &m_bg1.m_dst);
	SDL_RenderCopy(m_pRenderer, m_pBGTexture, &m_bg2.m_src, &m_bg2.m_dst);

	if (m_player != nullptr)
	{
		SDL_RenderCopyEx(m_pRenderer, m_pTexture, &m_player->m_src, &m_player->m_dst, 90.0, NULL, SDL_FLIP_NONE);
	}

	for (int i = 0; i < m_laser.size(); i++)
	{
		m_laser[i]->Render(m_pRenderer, m_lTexture);
	}
	for (int i = 0; i < m_aliens.size(); i++)
	{
		m_aliens[i]->Render(m_pRenderer, m_aTexture);
	}
	for (int i = 0; i < m_shoot.size(); i++)
	{
		m_shoot[i]->Render(m_pRenderer, m_aLTexture);
	}
	for (int i = 0; i < m_asteroid.size(); i++)
	{
		m_asteroid[i]->Render(m_pRenderer, m_aSTexture);
	}
	for (int i = 0; i < m_bomb.size(); i++)
	{
		m_bomb[i]->Render(m_pRenderer, m_bTexture);
	}

	SDL_RenderPresent(m_pRenderer); // Flip buffers - send data to window.
}

void Engine::Sleep()
{
	m_end = SDL_GetTicks();
	m_delta = m_end - m_start; // 1055 - 1050 = 5ms
	if (m_delta < m_fps)
		SDL_Delay(m_fps - m_delta);

}

int Engine::Run()
{
	if (m_running == true)
	{
		return 1;
	}
	// Start and run the "engine"
	if (Init("GAME1007 M1", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT, SDL_WINDOW_RESIZABLE) == false)
	{
		return 2;
	}
	// We passed our initial checks, start the loop!
	while (m_running == true)
	{
		Wake();
		HandleEvents(); // Input
		Update();       // Processing
		Render();       // Output
		if (m_running == true)
			Sleep();
	}
	Clean();
	return 0;
}


void Engine::Clean()
{
	cout << "Cleaning engine..." << endl;

	for (int i = 0; i < m_laser.size(); i++)
	{
		delete m_laser[i];
		m_laser[i] = nullptr;
	}
	m_laser.clear();
	m_laser.shrink_to_fit();

	for (int i = 0; i < m_aliens.size(); i++)
	{
		delete m_aliens[i];
		m_aliens[i] = nullptr;
	}
	m_aliens.clear();
	m_aliens.shrink_to_fit();

	for (int i = 0; i < m_shoot.size(); i++)
	{
		delete m_shoot[i];
		m_shoot[i] = nullptr;
		
	}
	m_shoot.clear();
	m_shoot.shrink_to_fit();

	for (int i = 0; i < m_asteroid.size(); i++)
	{
		delete m_asteroid[i];
		m_asteroid[i] = nullptr;
	}
	m_asteroid.clear();
	m_asteroid.shrink_to_fit();

	for (int i = 0; i < m_bomb.size(); i++)
	{
		delete m_bomb[i];
		m_bomb[i] = nullptr;
	}
	m_bomb.clear();
	m_bomb.shrink_to_fit();

	SDL_DestroyRenderer(m_pRenderer);
	SDL_DestroyWindow(m_pWindow);
	SDL_DestroyTexture(m_pTexture);
	SDL_DestroyTexture(m_pBGTexture);
	SDL_DestroyTexture(m_lTexture);
	SDL_DestroyTexture(m_aTexture);
	SDL_DestroyTexture(m_aLTexture);
	SDL_DestroyTexture(m_aSTexture);
	SDL_DestroyTexture(m_bTexture);
	SDL_Quit();
	Mix_FreeChunk(m_boom);
	Mix_FreeChunk(m_death);
	Mix_FreeChunk(m_plaser);
	Mix_FreeChunk(m_alaser);
	Mix_FreeMusic(m_odd);
	Mix_CloseAudio();
	Mix_Quit();
}